# PROJECT TITLE 


## NON-TECHNICAL EXPLANATION OF YOUR PROJECT
100 words to explain what your project is about to a general audience.

The project is about automated hyperparameter tuning using Bayesian Optimization. Specifically, we 
will optimize the hyperparameters of a Gradient Boosting Machine using the Hyperopt library (with 
the Tree Parzen Estimator algorithm). We will compare the results of random search (implemented 
manually) for hyperparameter tuning with the Bayesian model-based optimization method to try and 
understand how the Bayesian method works and what benefits it has over uninformed search methods.

The data used in the notebook is from the Caravan Insurance Challenge dataset available on Kaggle. 
The objective is to determine whether or not a potential customer will buy an insurance policy by 
training a model on past data. This is a straightforward supervised machine learning classification 
task: given past data, we want to train a model to predict a binary outcome on testing data.

## DATA
A summary of the data you’re using, remembering to include where you got it and any relevant
citations.

This dataset is owned and supplied by the Dutch datamining company Sentient Machine Research, and 
is based on real world business data. You are allowed to use this dataset and accompanying 
information for non commercial research and education purposes only. It is explicitly not allowed 
to use this dataset for commercial education or demonstration purposes. For any other use, please 
contact Peter van der Putten, info@smr.nl.

This dataset has been used in the CoIL Challenge 2000 datamining competition. For papers describing 
results on this dataset, see the TIC 2000 homepage: 
http://www.wi.leidenuniv.nl/~putten/library/cc2000/

Please cite/acknowledge:
P. van der Putten and M. van Someren (eds) . CoIL Challenge 2000: The Insurance Company Case. 
Published by Sentient Machine Research, Amsterdam. Also a Leiden Institute of Advanced Computer 
Science Technical Report 2000-09. June 22, 2000.

## MODEL 
A summary of the model you’re using and why you chose it. 
Bayesian optimisation using in this project inlcuding Hyperopt library.
Hyperopt is one of several automated hyperparameter tuning libraries using Bayesian optimization. 
These libraries differ in the algorithm used to both construct the surrogate (probability model) of 
the objective function and choose the next hyperparameters to evaluate in the objective function. 
Hyperopt uses the Tree Parzen Estimator (TPE). Other Python libraries include Spearmint, which uses 
a Gaussian process for the surrogate, and SMAC, which uses a random forest regression.

Hyperopt has a simple syntax for structuring an optimization problem which extends beyond 
hyperparameter tuning to any problem that involves minimizing a function. Moreover, the structure 
of a Bayesian Optimization problem is similar across the libraries, with the major differences 
coming in the syntax (and in the algorithms behind the scenes that we do not have to deal with)

LightGBM implementation of the gradient boosting machine has been used to define default 
hyperparameters. This is much faster than the Scikit-Learn implementation and achieves results 
comparable to extreme gradient boosting, XGBoost. For the baseline model, we have used the default 
hyperparameters as specified in LightGBM.

## HYPERPARAMETER OPTIMSATION
Description of which hyperparameters you have and how you chose to optimise them. 
The following hyperparameters are used:
1. class_weight : Estimate class weights for unbalanced datasets.
2. boosting_type : Traditional Gradient Boosting Decision Tree
3. num_leaves : Maximum tree leaves for base learners
4. learning_rate : Boosting learning rate.
5. subsample_for_bin : Number of samples for constructing bins
6. min_child_samples : Minimum number of data needed in a child (leaf).
7. reg_alpha : L1 regularization term on weights.
8. reg_lambda : L2 regularization term on weights.
9. colsample_bytree : Subsample ratio of columns when constructing each tree.


## RESULTS
A summary of your results and what you can learn from your model 

You can include images of plots using the code below:
![Screenshot](image.png)


## (OPTIONAL: CONTACT DETAILS)
If you are planning on making your github repo public you may wish to include some contact information such as a link to your twitter or an email address. 

