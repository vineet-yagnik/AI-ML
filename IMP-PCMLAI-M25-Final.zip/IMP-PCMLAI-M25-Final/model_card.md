# Model Card

See the [example Google model cards](https://modelcards.withgoogle.com/model-reports) for inspiration. 

## Model Description

**Input:** Describe the inputs of your model
The model is about automated hyperparameter tuning using Bayesian Optimization. Specifically, we 
will optimize the hyperparameters of a Gradient Boosting Machine using the Hyperopt library (with 
the Tree Parzen Estimator algorithm). We will compare the results of random search (implemented 
manually) for hyperparameter tuning with the Bayesian model-based optimization method to try and 
understand how the Bayesian method works and what benefits it has over uninformed search methods.

**Output:** Describe the output(s) of your model
The objective is to determine whether or not a potential customer will buy an insurance policy by 
training a model on past data. This is a straightforward supervised machine learning classification 
task: given past data, we want to train a model to predict a binary outcome on testing data.

**Model Architecture:** Describe the model architecture you’ve used
The key focus is on the application and evaluation of using Hyperopt bayesian 
library. Hyperopt is one of several automated hyperparameter tuning libraries using 
Bayesian optimization. These libraries differ in the algorithm used to both 
construct the surrogate (probability model) of the objective function and choose 
the next hyperparameters to evaluate in the objective function. Hyperopt uses the 
Tree Parzen Estimator (TPE). Other Python libraries include Spearmint, which uses a 
Gaussian process for the surrogate, and SMAC, which uses a random forest regression.

Hyperopt has a simple syntax for structuring an optimization problem which extends 
beyond hyperparameter tuning to any problem that involves minimizing a function.    
Moreover, the structure of a Bayesian Optimization problem is similar across the 
libraries, with the major differences coming in the syntax (and in the algorithms 
behind the scenes that we do not have to deal with).

## Performance

Give a summary graph or metrics of how the model performs. Remember to include how 
you are measuring the performance and what data you analysed it on. 

The details are present in the jupyter notebook attached.

## Limitations

Outline the limitations of your model.
Bayesian model-based optimization can be more efficient than random search, finding a better set of 
model hyperparameters in fewer search iterations (although not in every case). However, just 
because the model hyperparameters are better on the validation set does not mean they are better 
for the testing set! For this training run, Bayesian Optimization found a better set of 
hyperparamters according to the validation and the test data although the testing score was much 
lower than the validation ROC AUC. This is a useful lesson that even when using cross-validation, 
overfitting is still one of the top problems in machine learning.

## Trade-offs

Outline any trade-offs of your model, such as any circumstances where the model exhibits 
performance issues. 

Optimization of hyperparameters is still prone to overfitting, even when using cross-validation 
because it can get settle into a local minimum of the objective function. It is very difficult to 
tell when this occurs for a high-dimensional problem!
